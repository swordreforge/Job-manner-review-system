-- 添加岗位分类功能
-- 执行日期: 2026-04-13

-- 1. 添加 category 字段
ALTER TABLE `jobs`
ADD COLUMN `category` VARCHAR(20) DEFAULT NULL
COMMENT '岗位分类：tech-技术研发, design-产品设计, ops-运营, sales-销售'
AFTER `industry`;

-- 2. 添加索引以提升查询性能
CREATE INDEX `idx_category` ON `jobs` (`category`);

-- 3. 为现有岗位数据设置分类
-- 技术研发类岗位
UPDATE `jobs` SET `category` = 'tech'
WHERE `name` LIKE '%开发%' OR `name` LIKE '%工程师%' OR `name` LIKE '%程序员%'
   OR `name` LIKE '%架构%' OR `name` LIKE '%测试%' OR `name` LIKE '%运维%'
   OR `name` LIKE '%前端%' OR `name` LIKE '%后端%' OR `name` LIKE '%算法%'
   OR `name` LIKE '%数据%';

-- 产品设计类岗位
UPDATE `jobs` SET `category` = 'design'
WHERE `name` LIKE '%产品%' OR `name` LIKE '%设计%' OR `name` LIKE '%UI%'
   OR `name` LIKE '%UX%' OR `name` LIKE '%交互%';

-- 运营类岗位
UPDATE `jobs` SET `category` = 'ops'
WHERE `name` LIKE '%运营%' OR `name` LIKE '%市场%' OR `name` LIKE '%推广%'
   OR `name` LIKE '%品牌%' OR `name` LIKE '%活动%';

-- 销售类岗位
UPDATE `jobs` SET `category` = 'sales'
WHERE `name` LIKE '%销售%' OR `name` LIKE '%商务%' OR `name` LIKE '%客户%'
   OR `name` LIKE '%渠道%' OR `name` LIKE '%大客户%';